# WebProyectoFinal
Proyecto Final Web(React)
Proyecto que muestra proporciones.

Install

npm install

Build Project

npm run-script build

Start Server

npm run-script start



